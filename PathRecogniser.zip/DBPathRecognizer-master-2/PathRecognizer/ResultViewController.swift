//
//  ResultViewController.swift
//  PathRecogniser
//
//  Created by Hazel Egan on 17/03/2016.
//  Copyright © 2016 Didier Brun. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var goButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var pass: UIImageView!
    @IBOutlet weak var fail: UIImageView!
    var score: Int?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pass.hidden = true
        fail.hidden = true
        if(score > 3){
            fail.hidden = false
            goButton.hidden = true
            goButton.enabled = false
        }
        else if (score < 4){
            pass.hidden = false
            backButton.hidden = true
            backButton.enabled = false
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
